#include <iostream>
#include <string>
#include <list>

using namespace std;

list<string> make_list(string text)
{
	int idx = -1;
	int idxTemp = 0;
	list<string> wordList;
	do
	{
		idxTemp = text.find(' ', idx + 1);
		string word = text.substr(idx + 1, idxTemp - idx - 1);
		wordList.push_back(word);
		idx = idxTemp;
	} while (idx != -1 || idxTemp != -1);
	return wordList;
}

int main()
{
	string text = "Want to improve your Korean writing ? Writing is an essential tool that will help you adjust to Korean university life.The Ha - Rang Writing Center offers a free tutoring program open to all international students at our university.We encourage you to take advantage of this.The program has always been very popular among international students.Registration opens from November 28 for three days only.Once you are registered, we will match you with a perfect tutor and contact you to arrange your schedule.We are sure that you will be satisfied with our well - experienced tutors. Don't miss this great opportunity to improve your Korean writing. For more information, feel free to email Jiyung Yoon, HRWC Director, at jyoon@hrwc.org.";
	for (auto iter : make_list(text))
		cout << iter << " ";
	return 0;
}