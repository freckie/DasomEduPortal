#include <iostream>
#include <string>

using namespace std;

int count(string text, string target)
{
	int idx = -1;
	int cnt = -1;

	do
	{
		idx = text.find(target, idx + 1);
		cnt++;
	} while (idx != -1);
	return cnt;
}

int sum_of_count()
{
	string text = "Want to improve your Korean writing? Writing is an essential tool that will help you adjust to Korean university life. The Ha-Rang Writing Center offers a free tutoring program open to all international students at our university. We encourage you to take advantage of this. The program has always been very popular among international students. Registration opens from November 28 for three days only. Once you are registered, we will match you with a perfect tutor and contact you to arrange your schedule. We are sure that you will be satisfied with our well-experienced tutors. Don't miss this great opportunity to improve your Korean writing. For more information, feel free to email Jiyung Yoon, HRWC Director, at jyoon@hrwc.org.";
	int numAt = count(text, "at");
	int numTo = count(text, "to");
	int numFrom = count(text, "from");
	int numOn = count(text, "on");
	return numAt + numTo + numFrom + numOn;
}

int main()
{
	string text = "Want to improve your Korean writing? Writing is an essential tool that will help you adjust to Korean university life. The Ha-Rang Writing Center offers a free tutoring program open to all international students at our university. We encourage you to take advantage of this. The program has always been very popular among international students. Registration opens from November 28 for three days only. Once you are registered, we will match you with a perfect tutor and contact you to arrange your schedule. We are sure that you will be satisfied with our well-experienced tutors. Don't miss this great opportunity to improve your Korean writing. For more information, feel free to email Jiyung Yoon, HRWC Director, at jyoon@hrwc.org.";
	string word;

	cout << "ã�� �ܾ� �Է�: ";
	cin >> word;

	cout << "�ܾ��� ������" << " " << count(text, word) << "��" << endl;
	
	cout <<"��ġ���� ������" << " " << sum_of_count() << "��" << endl;
}	